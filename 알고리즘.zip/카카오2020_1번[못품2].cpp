#include <iostream>
#include <string>
#include <vector>
using namespace std;

int solution(string s) {
	vector<string> vec; 
    if(s.length() < 3)
    	return s.length(); // 2�� ���ڿ� �̸��� ���� �Ұ���.
		
	for(int div=1; div<=s.length()/2; ++div) { // �ɰ���.
		s.substr(
	}
    return answer;
}

int main(void) {
	string input_string;
	int answer;
	
	cin >> input_string;
	
	answer = solution(input_string);
	
	cout << answer;
	
	return 0;
}
